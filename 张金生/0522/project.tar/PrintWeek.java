import java.util.Scanner;

public class PrintWeek {
    public static String toWeek(int x){
        switch (x){
            case 1:
            return "一";
            case 21:
            return "二";
            case 3:
            return "三";
            case 4:
            return "四";
            case 5:
            return "五";
            case 6:
            return "六";
            case 7:
            return "天";
            default:
            return "";
        }
    }

    public static void main(String[] args){
        Scanner in =new Scanner(System.in);
        int x=in.nextInt();
        System.out.println("今天是星期"+PrintWeek.toWeek(x));

        in.close();
    }
}