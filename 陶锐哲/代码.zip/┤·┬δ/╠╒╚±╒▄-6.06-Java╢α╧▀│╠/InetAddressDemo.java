package Socket;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class InetAddressDemo{
    public static void main(String[] args){
        try{
            InetAddress shiyanlou = InetAddress.getByName("www.shiyanlou.com");
            //�����������IP��ַ
            System.out.println(shiyanlou.toString());
            //��ȡip��ַ
            String ip = shiyanlou.toString().split("/")[1];
            System.out.println(ip);
            //����ip��ַ��ȡ������
            InetAddress byAddress = InetAddress.getByName(ip);
            System.out.println("get hostname by IP address:" + byAddress.getHostName());
            System.out.println("localhost:" + byAddress.getLocalHost());
        }
        catch(UnknownHostException e){
            e.printStackTrace();
        }
    }
}