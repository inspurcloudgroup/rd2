package Socket;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class EchoClient{
    //�ͻ���

    public static void main(String[] args){
        //String hostname = "127.0.0.1";
    	
        //Socket�˿�
        int port = 1080;
        Scanner userIn = new Scanner(System.in);
        try{
            String hostname = InetAddress.getLocalHost().toString().split("/")[1];
            //����Socket����
            Socket socket = new Socket(hostname, port);
            //��ȡsocket�����
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            //��ȡ������
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            String userInput;
            System.out.println("��������ϢΪ��");
            //���exit���˳�
            while (!"exit".equals(userInput = userIn.nextLine())){
                out.println(userInput);
                System.out.println("�յ�����˻�Ӧ��" + in.readLine());
            }
            socket.close();
        }
        catch(IOException e){
            e.printStackTrace();
        }

    }
}