package Socket;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;

public class HttpUrlTest {
    public static void main(String[] args) {
        try {
            //����url
            URL shiyanlou = new URL("https://www.baidu.com/");
            //������
            HttpURLConnection urlConnection = (HttpURLConnection)shiyanlou.openConnection();
            //�������󷽷�
            urlConnection.setRequestMethod("GET");
            //�������ӳ�ʱʱ��
            urlConnection.setConnectTimeout(1000);
            //��ȡ������
            InputStream inputStream = urlConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            //��ӡ���
            bufferedReader.lines().forEach(System.out::println);
            //�ر�����
            inputStream.close();
            bufferedReader.close();
            urlConnection.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}