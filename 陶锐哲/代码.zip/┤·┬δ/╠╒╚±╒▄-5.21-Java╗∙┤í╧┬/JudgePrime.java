package All;

public class JudgePrime {
    public static void main(String[] args){
        int [] ages = {12, 18, 9, 33, 45, 60};
        int i = 1;
        for(int age:ages){
            System.out.println("�����е�"+i+"��Ԫ����"+age);
            i++;
        }
    }
}
