package All;

import java.util.*;

public class InputTest
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        String[] info= new String[100];
        int i = 0;
        while (!sc.hasNext("end"))
        {
            info[i] = sc.nextLine();
            i++;
        }
        sc.close();

        for (int j = 1; j < i; j++)
        {
            System.out.println(info[j]);
        }
    }
}