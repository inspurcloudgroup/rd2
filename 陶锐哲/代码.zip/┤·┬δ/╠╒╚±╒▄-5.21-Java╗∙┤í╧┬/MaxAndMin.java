package All;

public class MaxAndMin{
    public static void main(String[] args)
    {
        int[] infos = {313, 89, 123, 323, 313, 15, 90, 56, 39};
        int max = 0, min = 999;
        for (int info:infos)
        {
            if (info > max) max = info;
            if (info < min) min = info;
        }
        //Max
        System.out.println(max);
        //Min
        System.out.println(min);
    }
}
