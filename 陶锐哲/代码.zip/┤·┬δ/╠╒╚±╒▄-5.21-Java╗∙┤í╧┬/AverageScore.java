package All;

public class AverageScore{
    public static void main(String[] args)
    {
        int[] score = {61, 57, 95, 85, 75, 65, 44, 66, 90, 32};
        int sum = 0;
        for (int s:score)
        {
            sum += s;
        }
        System.out.println(sum/score.length);
    }
}
