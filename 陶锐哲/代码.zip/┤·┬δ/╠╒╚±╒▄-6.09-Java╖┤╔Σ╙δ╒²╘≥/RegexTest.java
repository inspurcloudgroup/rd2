/*
 * ƥ��11λ�ֻ�����
 */

package regexDemo;

import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.*;

public class RegexTest {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		String phoneNumber = sc.nextLine();
		
		Pattern pattern = Pattern.compile("^((13[0-9])|(14[579])|(15([0-3,5-9]))|(16[6])|(17[0135678])|(18[0-9]|19[89]))\\d{8}$");
		Matcher matcher = pattern.matcher(phoneNumber);
		System.out.println(matcher.matches());
	}

}
