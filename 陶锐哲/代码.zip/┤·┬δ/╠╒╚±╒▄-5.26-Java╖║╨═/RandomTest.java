import java.util.*;

public class RandomTest{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int m = sc.nextInt();
        int n = sc.nextInt();
        Random rd = new Random();
        System.out.println(rd.nextInt(n - m + 1) + n);
    }

}