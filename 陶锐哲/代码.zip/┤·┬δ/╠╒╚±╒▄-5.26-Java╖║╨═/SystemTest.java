import java.util.Arrays;

public class SystemTest{
    public static void main(String[] args)
    {
        System.out.println(System.getProperty("java.home"));

        int[] a = {1, 2, 3, 4, 5, 6, 7};
        String[] b = {"c", "d", "e", "f"};

        try
        {
            System.arraycopy(a, 1, b, 2, 1);
            System.out.println(b);
        }
        catch(Exception e)
        {
            System.out.println("���ƴ���");
        }

    }
}