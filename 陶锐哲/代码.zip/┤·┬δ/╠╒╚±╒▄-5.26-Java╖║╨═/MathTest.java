import java.util.*;

public class MathTest{
    public static void main(String[] args){
        double a = Math.random();
        double b = Math.random();
        System.out.println(Math.max(a, b));
    }
}