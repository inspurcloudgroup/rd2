package ProviderConsumerTest;

import java.util.Random;
import java.util.concurrent.LinkedBlockingQueue;

public class ProviderConsumerTest {
		private static LinkedBlockingQueue<Integer> queue1 = new LinkedBlockingQueue<>();
		private static LinkedBlockingQueue<Integer> queue2 = new LinkedBlockingQueue<>();
		
		public static void main(String[] args) {
			//������1
			Thread provider1 = new  Thread(() -> {
				Random random = new Random();
				for (int i = 1; i < 4; i++) {
					try {
						int integer =random.nextInt();
						queue1.put(integer);
						System.out.println("��������1��" + integer);
					}
					catch(InterruptedException e) {
						e.printStackTrace();
					}
				}
			});
			
			//������2
			Thread provider2 = new  Thread(() -> {
				Random random = new Random();
				for (int i = 1; i < 4; i++) {
					try {
						int integer =random.nextInt();
						queue2.put(integer);
						System.out.println("��������2��" + integer);
					}
					catch(InterruptedException e) {
						e.printStackTrace();
					}
				}
			});
			
			//������1
			Thread consumer1 = new  Thread(() -> {
				int integer;
				for (int i = 1; i < 4; i++) {
					try {
						integer = queue1.take();
						System.out.println("��������1��" + integer);
						Thread.sleep(1000);
					}
					catch(InterruptedException e) {
						e.printStackTrace();
					}
				}
			});
			
			//������2
			Thread consumer2 = new  Thread(() -> {
				int integer;
				for (int i = 1; i < 4; i++) {
					try {
						integer = queue2.take();
						System.out.println("��������2��" + integer);
						Thread.sleep(1000);
					}
					catch(InterruptedException e) {
						e.printStackTrace();
					}
				}
			});
			
			
			provider1.start();
			provider2.start();
			consumer1.start();
			consumer2.start();
		}
}
