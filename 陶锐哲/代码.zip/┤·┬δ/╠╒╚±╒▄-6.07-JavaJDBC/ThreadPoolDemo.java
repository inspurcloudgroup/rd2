package threadPoolDemo;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadPoolDemo{

    private static ExecutorService executorService = Executors.newFixedThreadPool(5);

    public static void main(String[] args){
        executorService.submit( () -> {
            for (int i = 0; i < 10; i++){
                System.out.print(i + " ");
            }
        });

        //ֹͣ�̳߳أ����ǵõȵ��̳߳��е�����ִ����Ϻ�Źر�
        executorService.shutdown();
    }
}
