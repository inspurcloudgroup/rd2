package ThreadTest;
/*
 * ���ﳢ����3��Thread�Ĵ�������
 */

import java.util.concurrent.locks.ReentrantLock;
import java.util.*;

public class ThreadTest {
	
	private static ReentrantLock rl1 = new ReentrantLock();
	private static ReentrantLock rl2 = new ReentrantLock();
	private static ReentrantLock rl3 = new ReentrantLock();
	
	public static void main(String[] args) {
		
		Thread thread1 = new Thread(() -> {
			rl1.lock();
			try {		
				System.out.println("A");
				System.out.println("B");
				System.out.println("C");
			}
			finally{
				rl1.unlock();
			}
		});
		thread1.start();
		
		Thread2 thread2 = new Thread2();
		rl2.lock();
		thread2.start();
		rl2.unlock();
		
		Thread thread3 = new Thread(new Thread3());
		rl3.lock();
		thread3.start();
		rl3.unlock();
	
	}
	
	static class Thread2 extends Thread{
		
		@Override
		public void run() {
			System.out.println("A");
			System.out.println("B");
			System.out.println("C");
		}
	}
	
	static class Thread3 implements Runnable{
		@Override
		public void run() {
			System.out.println("A");
			System.out.println("B");
			System.out.println("C");
		}
	}
}
