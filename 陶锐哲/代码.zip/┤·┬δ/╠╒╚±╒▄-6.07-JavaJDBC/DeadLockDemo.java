package DeadLockDemo;

public class DeadLockDemo{
    private static Object lockA = new Object();
    private static Object lockB = new Object();

    public static void main(String[] args){
        //ʹ��lambda����ʽ��������

        //�߳�1
        new Thread(() ->{
            synchronized (lockA){
                try{
                    //�߳�����һ��ʱ�䣬ȷ������һ���̻߳�ȡb��
                    Thread.sleep(1000);
                }
                catch(InterruptedException e){
                    e.printStackTrace();
                }
                System.out.println("D");
                synchronized(lockB){
                }
            }
        }
        ).start();

        //�߳�2
        new Thread(() ->{
            synchronized(lockB){
                System.out.println("����...");
                synchronized(lockA){

                }
            }
        }
        ).start();
        
    }
}
