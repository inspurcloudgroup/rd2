import java.util.Arrays;

public class InsertSort{

    public static void Sort(int[] arr){
        int  temp;
        for (int i = 1; i < arr.length; i++)
            for (int j = 0; j < i ; j++)
            {
                if (arr[i] < arr[j])  //����˼·���ԣ�Ӧ���ǽ�����������в���
                {
                    temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;
                }
            }
    }

    public static void main(String[] args){
        int[] arr = {5, 4, 3, 1, 2};
        Sort(arr);
        System.out.println(Arrays.toString(arr));
    }

}