package people;

public class CellPhone extends TelePhone {

    @Override
    public void call() {
        System.out.println("�ҿ��Դ�绰��");
    }

    @Override
    public void message() {
        System.out.println("�ҿ��Է����ţ�");
    }

    public static void main(String[] args) {
        CellPhone cp = new CellPhone();
        cp.call();
        cp.message();
    }

}
