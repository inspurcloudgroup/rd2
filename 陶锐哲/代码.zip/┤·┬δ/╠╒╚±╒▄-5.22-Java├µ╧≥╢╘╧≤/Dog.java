package people;

public class Dog extends Animal {
}
