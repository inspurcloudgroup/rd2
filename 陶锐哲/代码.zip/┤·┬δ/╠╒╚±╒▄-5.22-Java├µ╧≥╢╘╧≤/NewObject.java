package people;

public class NewObject {
    public static void main(String[] args) {
        People LiLei = new People(); //����һ��People����LiLei

        LiLei.height =170;
        LiLei.age = 20;
        LiLei.sex = 1;

        LiLei.printBaseMes();
    }
}
