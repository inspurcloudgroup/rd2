package all;

public class FinalVar{
    public static void main(String[] args){
        final String FINAL_STRING="shiyanlou";
        System.out.println(FINAL_STRING);
    }
}