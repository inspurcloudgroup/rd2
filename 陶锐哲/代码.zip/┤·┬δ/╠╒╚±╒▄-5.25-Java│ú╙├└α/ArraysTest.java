import java.util.Arrays;

public class ArrayTest{
    public static void main(String[] args)
    {
        int[] N = {6, 17, 92, 32, 58, 22, 84, 66, 36, 33};
        Arrays.sort(N);
        System.out.println(Arrays.toString(N));
        int n = 33;
        int i = Arrays.binarySearch(N, n);
        System.out.println(i);
        try
        {
            int[] N1 = {6, 17, 92, 32, 58, 22, 84, 66, 36, 33};
            System.out.println(Arrays.binarySearch(N1, n));
        }
        catch(Exception e)
        {
            System.out.println("Cannt do this!");
        }
    }
}