import java.util.Arrays;
import java.util.Random;

public class ArraysDemo{
    public static void main(String[] args)
    {
        int[] arr = new int[10];
        //-----------------------------------//
        //����Ԫ�ض��趨Ϊ9
        Arrays.fill(arr,9);
        System.out.println("fill:" + Arrays.toString(arr));
        //-----------------------------------//
        //ʹ��100���ڵ������
        Random random = new Random();
        for (int i =0; i < arr.length; i++)
        {
            arr[i] = random.nextInt(101);
        }
        System.out.println("���¸�ֵ��" + Arrays.toString(arr));
        //-----------------------------------//
        arr[5] = 50;
        Arrays.sort(arr);
        System.out.println("Sort�����" + Arrays.toString(arr));
        //-----------------------------------//
        int i =Arrays.binarySearch(arr,50);
        System.out.println("ֵΪ50��Ԫ��������" + i);
        //-----------------------------------//
        int[] newArr = Arrays.copyOf(arr, arr.length);
        System.out.println("equals��" + Arrays.equals(arr, newArr));
    }
}