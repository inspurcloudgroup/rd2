package RandomFile;

public class RandomFile {

}
