package MoveDemo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class MoveDemo {

	public static void main(String[] args) {

		try {
			Files.move(Paths.get("E:\\Desktop\\MyJavaDir/3.txt"), Paths.get("E:\\\\Desktop\\\\MyJavaDir/1.txt"),
					StandardCopyOption.REPLACE_EXISTING);
			System.out.println("DONE!");
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("FALSE!");
		}
	}

}
