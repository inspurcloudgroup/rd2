package FileToUnicode;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class FileToUnicode {

	public static void main(String[] args) {
		try {
			FileInputStream fis = new FileInputStream("file1.txt");
			InputStreamReader isr = new InputStreamReader(fis);
			BufferedReader reader = new BufferedReader(isr);
			String s;
			while ((s = reader.readLine()) != null) {
				System.out.println("read:" + s);
			}
			reader.close();
			isr.close();
			fis.close();
		}
		catch(IOException e) {
			System.out.println(e);
		}

	}

}
