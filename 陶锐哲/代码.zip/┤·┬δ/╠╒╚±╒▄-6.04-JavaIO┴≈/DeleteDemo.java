package DeleteDemo;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import java.nio.file.Files;

public class DeleteDemo {

	public static void main(String[] args) {

		try {
			// �ļ���횴���,��t��������
			Files.delete(Paths.get("E:\\Desktop\\MyJavaDir/2.txt"));
			//�h������false
			System.out.println(Files.deleteIfExists(Paths.get("E:\\Desktop\\MyJavaDir/2.txt")));
			
			File file = new File("E:\\Desktop\\MyJavaDir/1.txt");
			//�h������false
			System.out.println(file.delete());
		}
		catch(IOException e){
			e.printStackTrace();
		}

	}

}
