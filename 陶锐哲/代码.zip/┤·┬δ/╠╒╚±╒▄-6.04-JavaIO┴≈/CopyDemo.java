package CopyDemo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class CopyDemo {

	public static void main(String[] args) {
		try {
			Files.copy(Paths.get("E:\\Desktop\\MyJavaDir/1.txt"), Paths.get("E:\\Desktop\\MyJavaDir/2.txt"), StandardCopyOption.REPLACE_EXISTING);
			System.out.println("Im Done!");
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}

}
