package Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.*;

public class Test {

	public static void main(String[] args) {
		try {
			File inFile = new File("E:\\Desktop\\MyJavaDir/1.txt");
			
			File outFile = new File("2.txt");  //δָ��·��,Ĭ�J��Project
			FileInputStream fis = new  FileInputStream(inFile);
			FileOutputStream fos = new FileOutputStream(outFile);
			int c;
			while((c = fis.read()) != -1) {
				fos.write(c);
			}
			System.out.println("Done!");
			fis.close();
			fos.close();
			
			//���ı��ļ�ݔ����
			FileReader file = new FileReader("E:\\Desktop\\MyJavaDir/1.txt");
			
			int data = 0;
			while((data = file.read()) != -1) //�xȡʧ������-1
			{
				System.out.print((char)data);
			}
			file.close();
		}
		catch(FileNotFoundException e) {
			System.out.println("FileStreamTest:" + e);
		}
		catch(IOException e) {
			System.out.println("FileStreamTest" + e);
		}
	}

}
